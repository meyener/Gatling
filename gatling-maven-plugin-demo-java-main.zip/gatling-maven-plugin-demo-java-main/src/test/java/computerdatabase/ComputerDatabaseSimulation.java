package computerdatabase;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;

import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.*;


public class ComputerDatabaseSimulation extends Simulation {

    private HttpProtocolBuilder httpProtocol=http
            .baseUrl("https://videogamedb.uk/api")
            .acceptHeader("application/json")
            .contentTypeHeader("application/json");


    //Feeder
    private static FeederBuilder.FileBased<Object> jsonFeeder=jsonFile("feeders/gameJsonFile.json");


    @Override
    public void before() {
        System.out.println("=====================");
        System.out.println("test started ...");
        System.out.println("=====================");
    }

    // set authorization
    private static ChainBuilder authorize=exec(http("Authenticate") // Named as Authenticate
            .post("/authenticate")
            .body(StringBody("{\n" +                                //Posting username and password
                    "  \"password\": \"admin\",\n" +
                    "  \"username\": \"admin\"\n" +
                    "}"))
            .check(jmesPath("token").saveAs("jwtToken")));       //authorization is return a token and has been named as jwtToken


    private static ChainBuilder getAllGames=exec(http("Get all games")
            .get("/videogame"));


    private static ChainBuilder createNewGame=
            feed(jsonFeeder.circular())
            .exec(http("Create a game - #{name}")
            .post("/videogame")
            .header("Authorization","Bearer #{jwtToken}")
                    .body(ElFileBody("feeders/feederBody.json")).asJson());


    private static ChainBuilder getLastGame=exec(http("Get Last Game - #{name}")
            .get("/videogame/#{id}")
            .check(jmesPath("name").isEL("#{name}")));

    private static ChainBuilder deleteGame=exec(http("Delete Game - #{name}")
            .delete("/videogame/#{id}")
            .header("authorization","Bearer #{jwtToken}"));

    private ScenarioBuilder scn=scenario("Video Game db Simulation").forever().on(
            exec(getAllGames)
                    .pause(2)
                    .exec(authorize)
                    .pause(2)
                    .exec(createNewGame)
                    .pause(1,5)
                    .exec(getLastGame)
                    .pause(3)
                    .exec(deleteGame)
    );

    {
        setUp(
                scn.injectOpen(
                        nothingFor(3),
                        rampUsers(50).during(10),
                        constantUsersPerSec(20).during(3)
                ).protocols(httpProtocol)
        ).maxDuration(50);
    }

    @Override
    public void after() {
        System.out.println("=====================");
        System.out.println("test completed ...");
        System.out.println("=====================");
    }
}
